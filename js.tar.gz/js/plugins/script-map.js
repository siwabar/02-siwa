jQuery(document).ready(function() {
    jQuery("#map1566739327259493916").simplegmaps({
        MapOptions: {
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoom: 8,
            scrollwheel: false,
        }
    });
});
jQuery(document).ready(function() {
    jQuery("#map2566739327259493916").simplegmaps({
        MapOptions: {
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoom: 8,
            scrollwheel: false,
        }
    });
});
jQuery(document).ready(function() {
    jQuery("#map3566739327259493916").simplegmaps({
        MapOptions: {
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoom: 8,
            scrollwheel: false,
        }
    });
});
jQuery(document).ready(function() {
    jQuery("#map4566739327259493916").simplegmaps({
        MapOptions: {
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoom: 8,
            scrollwheel: false,
        }
    });
});